#pragma once

#include "ActorHandle.h"
#include "Native.h"
#include "Transform.h"

class Actor {
    Transform* _transform;
    char _0x8[176];

public:
    inline Vector3& GetPosition() {
        if (_transform) {
            return _transform->GetPosition();
        }

        static Vector3 invalid = Vector3 { -1e6, -1e6, -1e6 };
        return invalid;
    }

    inline Transform* GetTransform() {
        return _transform;
    }
};

DECLARE_NATIVE_FUNC(Actor, GetActor, ::Actor*, (ActorHandle*))

DECLARE_NATIVE(Actor,
    MEMBER(GetActor)
)

MSM2SCRIPTSDK_API Actor* GetActor(ActorHandle* handle);
